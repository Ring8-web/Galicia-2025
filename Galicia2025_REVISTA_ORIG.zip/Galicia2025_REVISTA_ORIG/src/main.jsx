import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import Galicia2025 from './revista/Galicia2025'
ReactDOM.createRoot(document.getElementById('root')).render(<React.StrictMode><Galicia2025/></React.StrictMode>)