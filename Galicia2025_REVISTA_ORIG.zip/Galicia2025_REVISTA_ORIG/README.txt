Galicia 2025 — Revista (modelo editable)
----------------------------------------
Estructura clásica (scroll vertical):
- Introducción
- Día 1..5: Mapa, Timeline, Destinos, Sabores, Momentos y Galería
- Fotos desde /public/fotos como diaX-Y.jpg y diaX-mapa.jpg
- Cada foto se puede descargar

Uso:
1) Doble clic: 01-setup.bat (login y enlace)
2) Doble clic: 02-deploy.bat (compila + push + despliegue a producción)

Edita textos en: src/revista/Galicia2025.jsx
Pon tus fotos en: public/fotos
Pon tus audios en: public/audios
